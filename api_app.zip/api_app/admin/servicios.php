<?php
error_reporting(0);
ini_set('display_errors', '0');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, PATCH, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../conexion.php'; 

$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($method) {
        case 'GET':
            $estadoParam = $_GET['estado'] ?? 'activos';

            if (isset($_GET['id'])) {
                $sql = "SELECT s.servicios_id AS id, s.nombre, s.descripcion, s.categorias_servicios_id, 
                               c.categoria AS categoria_nombre, s.costo, s.fecha_registro, s.estado_general_id 
                        FROM servicios s
                        LEFT JOIN categorias_servicios c ON s.categorias_servicios_id = c.categorias_servicios_id
                        WHERE s.servicios_id = :id LIMIT 1";
                $stmt = $conexion->prepare($sql);
                $stmt->execute([':id' => $_GET['id']]);
                $data = $stmt->fetch(PDO::FETCH_ASSOC);
            } else {
                $sql = "SELECT s.servicios_id AS id, s.nombre, s.descripcion, s.categorias_servicios_id, 
                               c.categoria AS categoria_nombre, s.costo, s.fecha_registro, s.estado_general_id 
                        FROM servicios s
                        LEFT JOIN categorias_servicios c ON s.categorias_servicios_id = c.categorias_servicios_id";
                
                if ($estadoParam === 'activos') {
                    $sql .= " WHERE s.estado_general_id = 1";
                } elseif ($estadoParam === 'inactivos') {
                    $sql .= " WHERE s.estado_general_id = 2";
                }
                
                $sql .= " ORDER BY s.nombre ASC";

                $stmt = $conexion->query($sql);
                $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
            
            echo json_encode(["success" => true, "data" => $data]);
            break;

        case 'POST':
            $input = json_decode(file_get_contents("php://input"), true);
            
            if (empty($input['nombre']) || empty($input['categorias_servicios_id']) || !isset($input['costo'])) {
                http_response_code(400);
                echo json_encode(["success" => false, "message" => "El nombre, categoría y costo son obligatorios."]);
                exit();
            }

            $estado = $input['estado_general_id'] ?? 1;

            $sql = "INSERT INTO servicios (nombre, descripcion, categorias_servicios_id, costo, estado_general_id, fecha_registro) 
                    VALUES (:nombre, :descripcion, :cat_id, :costo, :estado, NOW())";
            
            $stmt = $conexion->prepare($sql);
            $stmt->execute([
                ':nombre'      => trim($input['nombre']),
                ':descripcion' => trim($input['descripcion'] ?? ''),
                ':cat_id'      => $input['categorias_servicios_id'],
                ':costo'       => $input['costo'],
                ':estado'      => $estado
            ]);

            http_response_code(201);
            echo json_encode([
                "success" => true, 
                "message" => "Servicio creado correctamente.", 
                "id" => $conexion->lastInsertId()
            ]);
            break;

        case 'PUT':
            $input = json_decode(file_get_contents("php://input"), true);

            if (empty($input['id']) || empty($input['nombre']) || empty($input['categorias_servicios_id']) || !isset($input['costo'])) {
                http_response_code(400);
                echo json_encode(["success" => false, "message" => "ID, nombre, categoría y costo son obligatorios."]);
                exit();
            }

            $sql = "UPDATE servicios 
                    SET nombre = :nombre, descripcion = :descripcion, categorias_servicios_id = :cat_id, costo = :costo 
                    WHERE servicios_id = :id";
                    
            $stmt = $conexion->prepare($sql);
            $stmt->execute([
                ':nombre'      => trim($input['nombre']),
                ':descripcion' => trim($input['descripcion'] ?? ''),
                ':cat_id'      => $input['categorias_servicios_id'],
                ':costo'       => $input['costo'],
                ':id'          => $input['id']
            ]);

            echo json_encode(["success" => true, "message" => "Servicio actualizado correctamente."]);
            break;

        case 'DELETE':
            $input = json_decode(file_get_contents("php://input"), true);
            $id = $_GET['id'] ?? $input['id'] ?? null;

            if (!$id) {
                http_response_code(400);
                echo json_encode(["success" => false, "message" => "ID de servicio no proporcionado."]);
                exit();
            }

            $stmt = $conexion->prepare("UPDATE servicios SET estado_general_id = 2 WHERE servicios_id = :id");
            $stmt->execute([':id' => $id]);

            echo json_encode(["success" => true, "message" => "Servicio inhabilitado correctamente."]);
            break;

        case 'PATCH':
            $input = json_decode(file_get_contents("php://input"), true);
            $id = $_GET['id'] ?? $input['id'] ?? null;

            if (!$id) {
                http_response_code(400);
                echo json_encode(["success" => false, "message" => "ID de servicio no proporcionado."]);
                exit();
            }

            $stmt = $conexion->prepare("UPDATE servicios SET estado_general_id = 1 WHERE servicios_id = :id");
            $stmt->execute([':id' => $id]);

            echo json_encode(["success" => true, "message" => "Servicio activado correctamente."]);
            break;

        default:
            http_response_code(405);
            echo json_encode(["success" => false, "message" => "Método no permitido."]);
            break;
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Error en la base de datos: " . $e->getMessage()]);
}
?>